package stepDefinition;

import java.io.File;

import org.junit.AfterClass;
import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

import com.cucumber.listener.Reporter;

//plugin = {"pretty","html:cucumberReports/"}


//import com.relevantcodes.extentreports.*;
import cucumber.runtime.CucumberException;
import cucumber.runtime.io.URLOutputStream;
import gherkin.formatter.Formatter;
//import gherkin.formatter.Reporter;
import gherkin.formatter.model.*;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URL;
import java.util.*;


@RunWith(Cucumber.class)
@CucumberOptions(
		
		 features = "C:/Users/welcome/Desktop/New Workspace/TestProject/src/stepDefinition"
		 ,glue={"C:/Users/welcome/Desktop/New Workspace/TestProject/src/stepDefinition"},
		 
		 		
		 plugin = { "com.cucumber.listener.ExtentCucumberFormatter:C:/Users/welcome/Desktop/New Workspace/TestProject/src/report.html"}
		//monochrome = true

				)

public class Runner {

	
	@AfterClass
	public static void writeExtentReport() {

		ConfigFileReader o = new ConfigFileReader();
		System.out.println(	o.getReportConfigPath() );
		
		Reporter.loadXMLConfig(new File(o.getReportConfigPath()));
	
	}
	
}
