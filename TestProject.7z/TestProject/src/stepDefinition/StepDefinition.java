package stepDefinition;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinition {
	
	WebDriver driver;
	


@Given("^Open browser$")
public void open_url() throws Throwable {
	

	System.setProperty("webdriver.ie.driver", "C:\\Users\\welcome\\Desktop\\Library\\IE32\\IEDriverServer.exe");
    
    driver = new InternetExplorerDriver();
	
}

@When("^Enter any data$")
public void user_enter_in_search_engine() throws Throwable {
	
	driver.get("www.google.com");

    
}

@Then("^Close browser$")
public void close_browser() throws Throwable {
	
	
	driver.close();
	
	System.out.println("close");

   
}

	
}
